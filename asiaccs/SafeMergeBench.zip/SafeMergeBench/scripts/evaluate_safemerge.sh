#!/bin/bash
# SafeMergeBench evaluation = MergeBench evaluation (scripts/evaluate.sh) with the
# fixes described in README_SAFEMERGE.md:
#   1. integrity gate before generation (config / chat template / merge recipe)
#   2. the safety chat template is chosen per model family instead of "llama3" for all
#   3. response-validity audit of every safety generation
#   4. extra safety benchmarks (held out from coefficient tuning)
#
# Usage:
#   bash scripts/evaluate_safemerge.sh MODEL GPU_ID OUTPUT_PATH BASE_MODEL "INPUT1 INPUT2 ..." [TEMPLATE] [EXPECT_ALGO]
# TEMPLATE: llama3 | gemma | ... (default: inferred from the model name; pretrained
#           bases without a chat template must be given explicitly).

set -euo pipefail

MODEL=$1
GPU_ID=$2
OUTPUT_PATH=$3
BASE_MODEL=$4
INPUTS=$5
TEMPLATE=${6:-}
EXPECT_ALGO=${7:-}

if [ -z "$TEMPLATE" ]; then
  case "$(basename "$MODEL") $(basename "$BASE_MODEL")" in
    *Instruct*) TEMPLATE=llama3 ;;
    *gemma*-it*) TEMPLATE=gemma ;;   # [要確認] template name registered in safety-eval-fork
    *) echo "ERROR: cannot infer chat template for $MODEL (pretrained base?). Pass TEMPLATE explicitly." >&2; exit 2 ;;
  esac
fi
echo "model=$MODEL template=$TEMPLATE gpu=$GPU_ID out=$OUTPUT_PATH"

export CUDA_VISIBLE_DEVICES=$GPU_ID
source "$(conda info --base)/etc/profile.d/conda.sh"
mkdir -p "$OUTPUT_PATH"
ROOT=$(pwd)

# ---- 1. integrity gate (fails fast; the model is reported as gate-failed) ----
GATE_ARGS=(--base "$BASE_MODEL" --inputs $INPUTS --merged "$MODEL" --eval-template "$TEMPLATE" --report "$OUTPUT_PATH/gate.json")
[ -n "$EXPECT_ALGO" ] && GATE_ARGS+=(--expect-algo "$EXPECT_ALGO")
if ! python "$ROOT/safemerge/integrity_gate.py" "${GATE_ARGS[@]}"; then
  echo "GATE FAILED: see $OUTPUT_PATH/gate.json" >&2
  exit 3
fi
echo "{\"template\": \"$TEMPLATE\", \"base\": \"$BASE_MODEL\", \"inputs\": \"$INPUTS\"}" > "$OUTPUT_PATH/eval_config.json"

# ---- 2. utility / generality: identical to MergeBench ----
conda activate lmeval
lm_eval --model hf --model_args pretrained="$MODEL" --tasks gsm8k_cot \
  --device cuda:0 --batch_size 16 --output_path "$OUTPUT_PATH"
lm_eval --model hf --model_args pretrained="$MODEL" \
  --tasks m_mmlu_fr,arc_fr,hellaswag_fr,m_mmlu_es,arc_es,hellaswag_es,m_mmlu_de,arc_de,hellaswag_de,m_mmlu_ru,arc_ru,hellaswag_ru \
  --device cuda:0 --batch_size 8 --output_path "$OUTPUT_PATH"
lm_eval --model hf --model_args pretrained="$MODEL" --tasks ifeval \
  --device cuda:0 --batch_size 8 --output_path "$OUTPUT_PATH"
conda deactivate

conda activate bigcode
pushd bigcode-evaluation-harness >/dev/null
accelerate launch main.py --model "$MODEL" --max_length_generation 512 --precision bf16 \
  --tasks humanevalplus,mbppplus --temperature 0.2 --n_samples 10 --batch_size 10 \
  --allow_code_execution --metric_output_path "$OUTPUT_PATH/code_eval.json" --use_auth_token
popd >/dev/null
conda deactivate

# ---- 3. safety: MergeBench tasks with the model's own template ----
conda activate safety-eval
pushd safety-eval-fork >/dev/null
export OPENAI_API_KEY=''
python evaluation/eval.py generators \
  --model_name_or_path "$MODEL" --use_vllm \
  --model_input_template_path_or_name "$TEMPLATE" \
  --tasks wildguardtest,harmbench,xstest,do_anything_now \
  --report_output_path "$OUTPUT_PATH/safety_eval.json" \
  --save_individual_results_path "$OUTPUT_PATH/safety_generation.json" \
  --batch_size 8
popd >/dev/null
conda deactivate

# ---- 4. extra safety benchmarks (held out from coefficient tuning) ----
# [要実装] JailbreakBench, StrongREJECT, WildJailbreak (eval split, de-duplicated against
# safety-eval's wildjailbreak:harmful with safemerge/split_overlap.py), TrustLLM jailbreak trigger.
# Write generations to $OUTPUT_PATH/safety_generation_extra.json in the same format,
# then judge each with HarmBench-cls, WildGuard and the StrongREJECT grader.

# ---- 5. response-validity audit ----
python "$ROOT/safemerge/validity_audit.py" "$OUTPUT_PATH" --out "$OUTPUT_PATH/validity" --sample 50

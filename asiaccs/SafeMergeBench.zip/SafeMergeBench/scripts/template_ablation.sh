#!/bin/bash
# Separates "collapse caused by merging" from "collapse caused by the chat template".
# Runs the MergeBench safety tasks on the base, every single expert, and the merged
# model, once with MergeBench's fixed "llama3" template and once with the model's own
# template, then audits response validity for each run.
#
# Usage: bash scripts/template_ablation.sh BASE GPU_ID OUT_ROOT MERGED OWN_TEMPLATE
#   e.g. bash scripts/template_ablation.sh meta-llama/Llama-3.2-3B 0 results/ablation \
#        merged_models/Llama-3.2-3B_merged/RegMeanPlusPlus_... llama3
# For pretrained bases with no chat template, OWN_TEMPLATE should be the plain
# (no-chat) format registered in safety-eval-fork [要確認: name].

set -euo pipefail
BASE=$1; GPU_ID=$2; OUT_ROOT=$3; MERGED=$4; OWN_TEMPLATE=$5
NAME=$(basename "$BASE")
MODELS=("$BASE")
for c in instruction math coding safety multilingual; do MODELS+=("MergeBench/${NAME}_${c}"); done
MODELS+=("$MERGED")

export CUDA_VISIBLE_DEVICES=$GPU_ID
source "$(conda info --base)/etc/profile.d/conda.sh"
ROOT=$(pwd)
conda activate safety-eval
export OPENAI_API_KEY=''
for M in "${MODELS[@]}"; do
  for T in llama3 "$OWN_TEMPLATE"; do
    OUT="$OUT_ROOT/$(basename "$M")/template_$T"
    [ -f "$OUT/safety_generation.json" ] && continue
    mkdir -p "$OUT"
    (cd safety-eval-fork && python evaluation/eval.py generators \
      --model_name_or_path "$M" --use_vllm \
      --model_input_template_path_or_name "$T" \
      --tasks wildguardtest,harmbench,xstest,do_anything_now \
      --report_output_path "$ROOT/$OUT/safety_eval.json" \
      --save_individual_results_path "$ROOT/$OUT/safety_generation.json" \
      --batch_size 8)
    python "$ROOT/safemerge/validity_audit.py" "$OUT" --out "$OUT/validity" --sample 0
  done
done
